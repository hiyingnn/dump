#!/bin/bash

# consolidate-apis.sh
# Consolidates Spring Boot Actuator mappings from multiple microservices
# Usage: ./consolidate-apis.sh <service-name> <actuator-url> [output-format]
#   output-format: json, csv, markdown (default: csv)

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Default values
OUTPUT_FORMAT="${3:-csv}"
OUTPUT_DIR="./api-consolidation"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Function to print colored messages
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to display usage
usage() {
    cat << EOF
Usage: $0 <service-name> <actuator-url> [output-format]

Arguments:
  service-name    Name of the microservice
  actuator-url    Full URL to the actuator mappings endpoint
                  Example: http://localhost:8080/actuator/mappings
  output-format   Output format: json, csv, markdown (default: csv)

Examples:
  $0 user-service http://localhost:8080/actuator/mappings csv
  $0 order-service https://api.example.com/actuator/mappings markdown

Multiple Services:
  To consolidate multiple services, create a services.txt file with:
  service-name|actuator-url
  
  Then run: $0 --batch services.txt [output-format]
EOF
    exit 1
}

# Check arguments
if [ $# -lt 2 ]; then
    if [ "$1" != "--batch" ]; then
        usage
    fi
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Function to fetch and parse actuator mappings
fetch_mappings() {
    local service_name=$1
    local actuator_url=$2
    
    log_info "Fetching mappings for $service_name from $actuator_url"
    
    # Fetch the mappings with timeout
    local response
    if ! response=$(curl -s --max-time 30 "$actuator_url" 2>&1); then
        log_error "Failed to fetch mappings from $actuator_url"
        return 1
    fi
    
    # Check if response is valid JSON
    if ! echo "$response" | jq empty 2>/dev/null; then
        log_error "Invalid JSON response from $actuator_url"
        return 1
    fi
    
    echo "$response"
}

# Function to parse mappings and extract API details
parse_mappings() {
    local service_name=$1
    local mappings_json=$2
    
    # Parse the mappings and extract relevant information
    echo "$mappings_json" | jq -r --arg service "$service_name" '
        .contexts // {} | 
        to_entries[] | 
        .value.mappings.dispatcherServlets // .value.mappings.dispatcherHandlers // {} |
        to_entries[] |
        .value[] |
        select(.predicate != null) |
        {
            service: $service,
            method: (
                if .details.requestMappingConditions.methods then 
                    .details.requestMappingConditions.methods | join(",")
                elif .predicate then
                    (.predicate | capture("\\{(?<method>[A-Z,]+)\\s") | .method // "ALL")
                else 
                    "ALL"
                end
            ),
            path: (
                if .details.requestMappingConditions.patterns then
                    .details.requestMappingConditions.patterns | join(",")
                elif .predicate then
                    (.predicate | capture("\\[(?<path>[^\\]]+)\\]") | .path // .predicate)
                else
                    .predicate // "N/A"
                end
            ),
            handler: (.handler // "N/A"),
            consumes: (
                if .details.requestMappingConditions.consumes then
                    (.details.requestMappingConditions.consumes | map(.mediaType) | join(","))
                else
                    "N/A"
                end
            ),
            produces: (
                if .details.requestMappingConditions.produces then
                    (.details.requestMappingConditions.produces | map(.mediaType) | join(","))
                else
                    "N/A"
                end
            ),
            params: (
                if .details.requestMappingConditions.params then
                    (.details.requestMappingConditions.params | map(.name) | join(","))
                else
                    "N/A"
                end
            ),
            headers: (
                if .details.requestMappingConditions.headers then
                    (.details.requestMappingConditions.headers | map(.name) | join(","))
                else
                    "N/A"
                end
            )
        }
    '
}

# Function to output as CSV
output_csv() {
    local service_name=$1
    local parsed_data=$2
    local output_file="$OUTPUT_DIR/${service_name}_apis_${TIMESTAMP}.csv"
    
    # Create CSV header
    echo "Service,Method,Path,Handler,Consumes,Produces,Params,Headers" > "$output_file"
    
    # Add data rows
    echo "$parsed_data" | jq -r '[.service, .method, .path, .handler, .consumes, .produces, .params, .headers] | @csv' >> "$output_file"
    
    log_info "CSV output saved to: $output_file"
    echo "$output_file"
}

# Function to output as JSON
output_json() {
    local service_name=$1
    local parsed_data=$2
    local output_file="$OUTPUT_DIR/${service_name}_apis_${TIMESTAMP}.json"
    
    echo "$parsed_data" | jq -s '.' > "$output_file"
    
    log_info "JSON output saved to: $output_file"
    echo "$output_file"
}

# Function to output as Markdown
output_markdown() {
    local service_name=$1
    local parsed_data=$2
    local output_file="$OUTPUT_DIR/${service_name}_apis_${TIMESTAMP}.md"
    
    cat > "$output_file" << EOF
# API Documentation: $service_name
Generated: $(date)

## Endpoints

EOF
    
    echo "$parsed_data" | jq -r '
        "| Method | Path | Handler | Consumes | Produces |",
        "|--------|------|---------|----------|----------|",
        (. | "| \(.method) | \(.path) | \(.handler) | \(.consumes) | \(.produces) |")
    ' >> "$output_file"
    
    log_info "Markdown output saved to: $output_file"
    echo "$output_file"
}

# Function to process a single service
process_service() {
    local service_name=$1
    local actuator_url=$2
    local output_format=$3
    
    log_info "Processing service: $service_name"
    
    # Fetch mappings
    local mappings
    if ! mappings=$(fetch_mappings "$service_name" "$actuator_url"); then
        return 1
    fi
    
    # Parse mappings
    local parsed_data
    parsed_data=$(parse_mappings "$service_name" "$mappings")
    
    if [ -z "$parsed_data" ]; then
        log_warn "No API mappings found for $service_name"
        return 1
    fi
    
    # Output based on format
    local output_file
    case "$output_format" in
        json)
            output_file=$(output_json "$service_name" "$parsed_data")
            ;;
        markdown|md)
            output_file=$(output_markdown "$service_name" "$parsed_data")
            ;;
        csv|*)
            output_file=$(output_csv "$service_name" "$parsed_data")
            ;;
    esac
    
    # Count APIs
    local api_count
    api_count=$(echo "$parsed_data" | jq -s 'length')
    log_info "Found $api_count APIs for $service_name"
    
    echo "$output_file"
}

# Function to consolidate multiple services
consolidate_multiple() {
    local batch_file=$1
    local output_format=$2
    local consolidated_file="$OUTPUT_DIR/consolidated_apis_${TIMESTAMP}"
    
    log_info "Batch processing services from $batch_file"
    
    if [ ! -f "$batch_file" ]; then
        log_error "Batch file not found: $batch_file"
        exit 1
    fi
    
    # Temporary file for all data
    local temp_data=$(mktemp)
    
    # Process each service
    while IFS='|' read -r service_name actuator_url; do
        # Skip empty lines and comments
        [[ -z "$service_name" || "$service_name" =~ ^# ]] && continue
        
        # Fetch and parse
        local mappings
        if mappings=$(fetch_mappings "$service_name" "$actuator_url"); then
            parse_mappings "$service_name" "$mappings" >> "$temp_data"
        fi
    done < "$batch_file"
    
    # Output consolidated data
    local consolidated_data
    consolidated_data=$(cat "$temp_data")
    
    case "$output_format" in
        json)
            echo "$consolidated_data" | jq -s '.' > "${consolidated_file}.json"
            log_info "Consolidated JSON: ${consolidated_file}.json"
            ;;
        markdown|md)
            cat > "${consolidated_file}.md" << EOF
# Consolidated API Documentation
Generated: $(date)

## All Services

EOF
            echo "$consolidated_data" | jq -r '
                "| Service | Method | Path | Handler | Consumes | Produces |",
                "|---------|--------|------|---------|----------|----------|",
                (. | "| \(.service) | \(.method) | \(.path) | \(.handler) | \(.consumes) | \(.produces) |")
            ' >> "${consolidated_file}.md"
            log_info "Consolidated Markdown: ${consolidated_file}.md"
            ;;
        csv|*)
            echo "Service,Method,Path,Handler,Consumes,Produces,Params,Headers" > "${consolidated_file}.csv"
            echo "$consolidated_data" | jq -r '[.service, .method, .path, .handler, .consumes, .produces, .params, .headers] | @csv' >> "${consolidated_file}.csv"
            log_info "Consolidated CSV: ${consolidated_file}.csv"
            ;;
    esac
    
    rm -f "$temp_data"
    
    # Summary
    local total_apis
    total_apis=$(echo "$consolidated_data" | wc -l)
    local total_services
    total_services=$(echo "$consolidated_data" | jq -r '.service' | sort -u | wc -l)
    
    log_info "Summary: $total_apis APIs across $total_services services"
}

# Main execution
if [ "$1" = "--batch" ]; then
    consolidate_multiple "$2" "${3:-csv}"
else
    process_service "$1" "$2" "$OUTPUT_FORMAT"
fi

log_info "Done!"
