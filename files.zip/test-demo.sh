#!/bin/bash

# test-demo.sh
# Demonstration script showing how to use the API consolidation tool

echo "=========================================="
echo "API Consolidation Tool - Demo"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}This demo will show you how to use the consolidate-apis.sh script${NC}"
echo ""

# Check prerequisites
echo "Checking prerequisites..."
command -v jq >/dev/null 2>&1 || { echo "jq is required but not installed. Install with: sudo apt-get install jq"; exit 1; }
command -v curl >/dev/null 2>&1 || { echo "curl is required but not installed."; exit 1; }
echo -e "${GREEN}✓ All prerequisites installed${NC}"
echo ""

# Create a mock HTTP server to simulate actuator endpoint
echo "Setting up mock actuator endpoint..."

# Start a simple HTTP server in background
cat > /tmp/serve-actuator.sh << 'EOF'
#!/bin/bash
while true; do
    { echo -ne "HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n\r\n"; cat sample-actuator-response.json; } | nc -l -p 9999 -q 1
done
EOF

chmod +x /tmp/serve-actuator.sh

# Start mock server in background
/tmp/serve-actuator.sh &
SERVER_PID=$!
echo "Mock server started (PID: $SERVER_PID) on http://localhost:9999"
sleep 2

echo ""
echo "=========================================="
echo "Demo 1: Single Service - CSV Output"
echo "=========================================="
echo ""
echo "Command: ./consolidate-apis.sh user-service http://localhost:9999 csv"
echo ""

./consolidate-apis.sh user-service http://localhost:9999 csv

echo ""
echo "Preview of generated CSV:"
if ls api-consolidation/user-service_apis_*.csv 1> /dev/null 2>&1; then
    latest_csv=$(ls -t api-consolidation/user-service_apis_*.csv | head -1)
    head -10 "$latest_csv"
fi

echo ""
echo "=========================================="
echo "Demo 2: Single Service - JSON Output"
echo "=========================================="
echo ""
echo "Command: ./consolidate-apis.sh user-service http://localhost:9999 json"
echo ""

./consolidate-apis.sh user-service http://localhost:9999 json

echo ""
echo "Preview of generated JSON:"
if ls api-consolidation/user-service_apis_*.json 1> /dev/null 2>&1; then
    latest_json=$(ls -t api-consolidation/user-service_apis_*.json | head -1)
    cat "$latest_json" | jq '.[0:2]'
fi

echo ""
echo "=========================================="
echo "Demo 3: Single Service - Markdown Output"
echo "=========================================="
echo ""
echo "Command: ./consolidate-apis.sh user-service http://localhost:9999 markdown"
echo ""

./consolidate-apis.sh user-service http://localhost:9999 markdown

echo ""
echo "Preview of generated Markdown:"
if ls api-consolidation/user-service_apis_*.md 1> /dev/null 2>&1; then
    latest_md=$(ls -t api-consolidation/user-service_apis_*.md | head -1)
    head -20 "$latest_md"
fi

echo ""
echo "=========================================="
echo "Demo 4: Batch Processing Multiple Services"
echo "=========================================="
echo ""

# Create a sample services file
cat > /tmp/demo-services.txt << EOF
user-service|http://localhost:9999
order-service|http://localhost:9999
payment-service|http://localhost:9999
EOF

echo "Created sample services.txt with multiple services"
cat /tmp/demo-services.txt
echo ""

echo "Command: ./consolidate-apis.sh --batch /tmp/demo-services.txt csv"
echo ""

./consolidate-apis.sh --batch /tmp/demo-services.txt csv

echo ""
echo "Preview of consolidated CSV:"
if ls api-consolidation/consolidated_apis_*.csv 1> /dev/null 2>&1; then
    latest_consolidated=$(ls -t api-consolidation/consolidated_apis_*.csv | head -1)
    head -15 "$latest_consolidated"
fi

# Cleanup
echo ""
echo "=========================================="
echo "Cleaning up..."
echo "=========================================="
kill $SERVER_PID 2>/dev/null
rm -f /tmp/serve-actuator.sh
rm -f /tmp/demo-services.txt
echo "Mock server stopped"

echo ""
echo "=========================================="
echo "Demo Complete!"
echo "=========================================="
echo ""
echo "Generated files are in: ./api-consolidation/"
echo ""
echo "Next steps:"
echo "1. Review the generated files in ./api-consolidation/"
echo "2. Try with your actual Spring Boot services"
echo "3. Create a services.txt file for batch processing"
echo "4. Integrate into your CI/CD pipeline"
echo ""
echo "For more information, see README.md"
echo ""
