# Quick Reference Guide

## Common Commands

### Single Service
```bash
# CSV format (default)
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings

# JSON format
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json

# Markdown format
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings markdown
```

### Multiple Services (Batch)
```bash
# Create services.txt file first
cat > services.txt << EOF
user-service|http://localhost:8080/actuator/mappings
order-service|http://localhost:8081/actuator/mappings
payment-service|http://localhost:8082/actuator/mappings
EOF

# Run batch processing
./consolidate-apis.sh --batch services.txt csv
./consolidate-apis.sh --batch services.txt json
./consolidate-apis.sh --batch services.txt markdown
```

## Spring Boot Configuration

### application.yml
```yaml
management:
  endpoints:
    web:
      exposure:
        include: mappings,health,info
  endpoint:
    mappings:
      enabled: true
```

### application.properties
```properties
management.endpoints.web.exposure.include=mappings,health,info
management.endpoint.mappings.enabled=true
```

## Output Files

All files are saved in `./api-consolidation/` directory:
- Single service: `{service-name}_apis_{timestamp}.{format}`
- Consolidated: `consolidated_apis_{timestamp}.{format}`

## Filtering Output

### Filter by HTTP Method
```bash
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json | \
  jq '.[] | select(.method == "GET")'
```

### Filter by Path Pattern
```bash
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json | \
  jq '.[] | select(.path | contains("/api/users"))'
```

### Count Total APIs
```bash
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json | \
  jq '. | length'
```

## CI/CD Integration Examples

### Jenkins
```groovy
stage('Document APIs') {
    steps {
        sh './consolidate-apis.sh --batch services.txt markdown'
        archiveArtifacts artifacts: 'api-consolidation/*.md'
    }
}
```

### GitLab CI
```yaml
document-apis:
  stage: document
  script:
    - ./consolidate-apis.sh --batch services.txt markdown
  artifacts:
    paths:
      - api-consolidation/*.md
```

### GitHub Actions
```yaml
- name: Generate API Documentation
  run: |
    ./consolidate-apis.sh --batch services.txt markdown
    
- name: Upload Documentation
  uses: actions/upload-artifact@v2
  with:
    name: api-documentation
    path: api-consolidation/*.md
```

## Testing Use Cases

### Import to Postman
1. Generate JSON output
2. Convert to Postman collection format
3. Import into Postman

### Import to JMeter
1. Generate CSV output
2. Use CSV Data Set Config in JMeter
3. Reference columns in HTTP Request sampler

### Generate Test Cases
```bash
# Get all endpoints
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json | \
  jq -r '.[] | "\(.method) \(.path)"'

# Output:
# GET /api/users
# POST /api/users
# PUT /api/users/{id}
# DELETE /api/users/{id}
```

## Troubleshooting

### Issue: "jq: command not found"
**Solution:**
```bash
# Ubuntu/Debian
sudo apt-get install jq

# macOS
brew install jq

# RHEL/CentOS
sudo yum install jq
```

### Issue: "Failed to fetch mappings"
**Solutions:**
1. Check if service is running: `curl http://localhost:8080/actuator/health`
2. Verify mappings endpoint: `curl http://localhost:8080/actuator/mappings`
3. Check firewall rules
4. Verify actuator is exposed in application.yml

### Issue: "Invalid JSON response"
**Solutions:**
1. Check actuator endpoint directly in browser
2. Verify Spring Boot version compatibility
3. Check for authentication requirements

### Issue: No APIs found
**Solutions:**
1. Ensure you have @RestController or @Controller classes
2. Verify application has started completely
3. Check actuator security settings

## Advanced Usage

### Compare APIs Between Environments
```bash
# Production
./consolidate-apis.sh user-service https://prod.example.com/actuator/mappings json > prod-apis.json

# Staging
./consolidate-apis.sh user-service https://staging.example.com/actuator/mappings json > staging-apis.json

# Compare
diff <(jq -S . prod-apis.json) <(jq -S . staging-apis.json)
```

### Generate API Changelog
```bash
# Before release
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json > before.json

# After release
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json > after.json

# Find new endpoints
jq -s '.[1] - .[0]' before.json after.json
```

### Secure Endpoints (with authentication)
```bash
# Modify the curl command in consolidate-apis.sh to add auth
curl -s --max-time 30 -H "Authorization: Bearer $TOKEN" "$actuator_url"
```

## Output Format Details

### CSV Columns
- Service: Microservice name
- Method: HTTP method(s)
- Path: Endpoint path/pattern
- Handler: Controller method
- Consumes: Accepted content types
- Produces: Response content types
- Params: Request parameters
- Headers: Required headers

### JSON Structure
```json
{
  "service": "user-service",
  "method": "GET",
  "path": "/api/users",
  "handler": "UserController.getAllUsers()",
  "consumes": "N/A",
  "produces": "application/json",
  "params": "N/A",
  "headers": "N/A"
}
```

## Tips & Best Practices

1. **Run regularly**: Schedule in CI/CD to keep documentation current
2. **Version control**: Commit generated docs to track API evolution
3. **Access control**: Secure actuator endpoints in production
4. **Filtering**: Use jq to extract specific subsets of APIs
5. **Automation**: Integrate with test generation tools
6. **Monitoring**: Compare outputs to detect unexpected API changes
