# Spring Boot API Consolidation Tool

A bash script to consolidate and document REST APIs from Spring Boot microservices using Actuator mappings endpoint.

## Features

- ✅ Fetch API mappings from Spring Boot Actuator endpoints
- ✅ Support for multiple microservices (batch processing)
- ✅ Multiple output formats: CSV, JSON, Markdown
- ✅ Extracts comprehensive API details:
  - HTTP Methods (GET, POST, PUT, DELETE, etc.)
  - Endpoint paths
  - Handler methods
  - Consumes/Produces media types
  - Request parameters
  - Headers
- ✅ Perfect for black box testing documentation
- ✅ Consolidated view across all services

## Prerequisites

- `bash` (version 4.0+)
- `curl` - for HTTP requests
- `jq` - for JSON parsing

### Installing Prerequisites

**Ubuntu/Debian:**
```bash
sudo apt-get install jq curl
```

**macOS:**
```bash
brew install jq curl
```

**RHEL/CentOS:**
```bash
sudo yum install jq curl
```

## Spring Boot Configuration

Ensure your Spring Boot applications have the actuator mappings endpoint enabled:

**application.yml:**
```yaml
management:
  endpoints:
    web:
      exposure:
        include: mappings,health,info
  endpoint:
    mappings:
      enabled: true
```

**application.properties:**
```properties
management.endpoints.web.exposure.include=mappings,health,info
management.endpoint.mappings.enabled=true
```

## Installation

1. Download the script:
```bash
curl -O https://raw.githubusercontent.com/your-repo/consolidate-apis.sh
chmod +x consolidate-apis.sh
```

2. Or clone this repository:
```bash
git clone <repository-url>
cd <repository-directory>
chmod +x consolidate-apis.sh
```

## Usage

### Single Service

Process a single microservice:

```bash
./consolidate-apis.sh <service-name> <actuator-url> [output-format]
```

**Examples:**

```bash
# Generate CSV (default)
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings

# Generate JSON
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json

# Generate Markdown
./consolidate-apis.sh order-service http://localhost:8081/actuator/mappings markdown
```

### Multiple Services (Batch Mode)

1. Create a `services.txt` file with your services:

```text
# Format: service-name|actuator-url
user-service|http://localhost:8080/actuator/mappings
order-service|http://localhost:8081/actuator/mappings
payment-service|http://localhost:8082/actuator/mappings
```

2. Run batch processing:

```bash
./consolidate-apis.sh --batch services.txt csv
```

This will create a consolidated file with APIs from all services.

## Output Formats

### CSV Format
Perfect for importing into Excel, Google Sheets, or test management tools.

```csv
Service,Method,Path,Handler,Consumes,Produces,Params,Headers
user-service,GET,/api/users,UserController.getAllUsers(),N/A,application/json,N/A,N/A
user-service,POST,/api/users,UserController.createUser(),application/json,application/json,N/A,N/A
```

### JSON Format
Ideal for programmatic processing and integration with testing frameworks.

```json
[
  {
    "service": "user-service",
    "method": "GET",
    "path": "/api/users",
    "handler": "UserController.getAllUsers()",
    "consumes": "N/A",
    "produces": "application/json",
    "params": "N/A",
    "headers": "N/A"
  }
]
```

### Markdown Format
Great for documentation and wikis.

```markdown
# API Documentation: user-service

## Endpoints

| Method | Path | Handler | Consumes | Produces |
|--------|------|---------|----------|----------|
| GET | /api/users | UserController.getAllUsers() | N/A | application/json |
| POST | /api/users | UserController.createUser() | application/json | application/json |
```

## Output Location

All output files are saved in the `./api-consolidation` directory with timestamps:

```
api-consolidation/
├── user-service_apis_20240209_143022.csv
├── order-service_apis_20240209_143025.json
├── payment-service_apis_20240209_143028.md
└── consolidated_apis_20240209_143030.csv
```

## Use Cases

### 1. Black Box Testing

Generate a complete API inventory for your QA team:

```bash
./consolidate-apis.sh --batch services.txt csv
```

Import the CSV into your test management tool (TestRail, Zephyr, qTest, etc.)

### 2. API Documentation

Create comprehensive API documentation:

```bash
./consolidate-apis.sh --batch services.txt markdown
```

Add the generated markdown to your wiki or documentation site.

### 3. API Contract Testing

Export to JSON for automated contract testing:

```bash
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json
```

Use the JSON output with tools like Pact, Spring Cloud Contract, or custom test scripts.

### 4. Security Auditing

Generate a complete list of endpoints for security review:

```bash
./consolidate-apis.sh --batch services.txt csv
```

Review which endpoints are exposed, their methods, and accepted content types.

### 5. API Versioning Analysis

Compare API changes between versions:

```bash
# Before deployment
./consolidate-apis.sh user-service http://prod:8080/actuator/mappings json > before.json

# After deployment
./consolidate-apis.sh user-service http://staging:8080/actuator/mappings json > after.json

# Compare
diff before.json after.json
```

## Integration Examples

### Integration with Newman/Postman

```bash
# Generate JSON
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json

# Convert to Postman collection (you'll need a custom script)
node convert-to-postman.js api-consolidation/user-service_apis_*.json > collection.json

# Run with Newman
newman run collection.json
```

### Integration with JMeter

```bash
# Generate CSV
./consolidate-apis.sh --batch services.txt csv

# Import CSV into JMeter test plan using CSV Data Set Config
```

### Integration with CI/CD

Add to your pipeline (Jenkins, GitLab CI, GitHub Actions):

```yaml
# .gitlab-ci.yml example
document-apis:
  stage: document
  script:
    - ./consolidate-apis.sh --batch services.txt markdown
    - cp api-consolidation/*.md docs/
  artifacts:
    paths:
      - docs/*.md
```

## Troubleshooting

### "Failed to fetch mappings"

1. Verify the actuator endpoint is accessible:
   ```bash
   curl http://localhost:8080/actuator/mappings
   ```

2. Check if mappings endpoint is enabled in Spring Boot config

3. Verify network connectivity and firewall rules

### "Invalid JSON response"

1. Check Spring Boot version compatibility (tested with 2.x and 3.x)
2. Ensure the actuator returns proper JSON format
3. Check for authentication requirements

### "jq: command not found"

Install jq using your package manager (see Prerequisites section)

### Empty output / No APIs found

1. Verify your Spring Boot app has REST controllers
2. Check if the application has fully started
3. Review actuator security settings

## Advanced Usage

### Custom Filtering

Filter specific endpoints using jq:

```bash
# Only GET endpoints
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json | \
  jq '.[] | select(.method == "GET")'

# Only /api/users paths
./consolidate-apis.sh user-service http://localhost:8080/actuator/mappings json | \
  jq '.[] | select(.path | contains("/api/users"))'
```

### Combining with Other Tools

```bash
# Generate and immediately view in Excel
./consolidate-apis.sh --batch services.txt csv && \
  libreoffice api-consolidation/consolidated_*.csv

# Generate and commit to git
./consolidate-apis.sh --batch services.txt markdown && \
  git add api-consolidation/*.md && \
  git commit -m "Update API documentation"
```

## Script Customization

You can modify the script to:
- Add custom fields from actuator response
- Filter out internal/admin endpoints
- Add API categorization
- Include authentication requirements
- Add rate limiting information

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - feel free to use and modify for your needs.

## Support

For issues and questions:
- Open an issue on GitHub
- Check Spring Boot Actuator documentation
- Review the troubleshooting section above

## Changelog

### Version 1.0.0
- Initial release
- Support for CSV, JSON, Markdown output
- Batch processing capability
- Color-coded logging
- Error handling and validation
