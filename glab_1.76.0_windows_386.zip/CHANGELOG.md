# Changelog

Changelogs for this project are available on the
[Releases page](https://gitlab.com/gitlab-org/cli/-/releases).
